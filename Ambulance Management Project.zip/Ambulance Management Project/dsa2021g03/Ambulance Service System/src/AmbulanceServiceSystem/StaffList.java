/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AmbulanceServiceSystem;

/**
 *
 * @author Proud To Be Muslims
 */
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class StaffList {

    private List<StaffDetails> staffDetails = new ArrayList<>();
    private DefaultTableModel model = new DefaultTableModel();
    private static StaffList instance;
    
   private StaffList() {

    }

    public List<StaffDetails> getStaffDetails() {
        return staffDetails;
    }

     public static StaffList getinstace() {
        if (instance == null) {
            instance = new StaffList();
            return instance;
        } else {
            return instance;
        }
    }
    public void addStaff(String name, String cnic, Date dob, String Address, String refnumber, String phnnumber, String catagory) {
        StaffDetails s = new StaffDetails();
        s.setID();
        String id = s.getID();
        StaffDetails details = new StaffDetails(name, cnic, dob, Address, refnumber, phnnumber, catagory, id);
        staffDetails.add(details);
    }

    public void EditStaff(String id) {
        for (int i = 0; i < staffDetails.size(); i++) {
            if (id.equals(staffDetails.get(i).getID())) {

            }
        }
    }

    public void SatffDetailTable(JTable table) {
        model = new DefaultTableModel();
        Object[] coloumns = {"ID", "Name", "Phone Number", "States"};
        model.setColumnIdentifiers(coloumns);
        table.setModel(model);
        DefaultTableModel model = (DefaultTableModel) table.getModel();

        for (int i = 0; i < staffDetails.size(); i++) {
            Object[] arr = new Object[4];
            arr[0] = staffDetails.get(i).getID();
            arr[1] = staffDetails.get(i).getName();
            arr[2] = staffDetails.get(i).getPhoneNumber();
            arr[3] = staffDetails.get(i).getStates();
            model.addRow(arr);
        }
    }

}
