/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AmbulanceServiceSystem;

/**
 *
 * @author Hassan Nawaz
 */
public class Linked_List<T> {

    private int size = 0;
    private Node<T> head;

    public int getSize() {
        return size;
    }

    public Node<T> getHead() {
        return head;
    }

    public void setHead(Node<T> head) {
        this.head = head;
    }

    public void insertFirst(T item) {
        Node<T> node = new Node<>();
        node.setItem(item);
        node.setNext(this.head);
        this.head = node;
        this.size++;
    }

    public void insertNode(T item) {
        Node<T> node = new Node<>();
        node.setItem(item);
        Node<T> current = this.head;

        if (this.head == null) {
            this.head = node;
            this.head.setNext(null);
            this.size = 1;
            
        } else {

            while (current.getNext() != null) {
                current = current.getNext();
            }
            current.setNext(node);
            node.setNext(null);
            this.size += 1;
        }
    }

    public void insertNth(T item, int position) {
        Node<T> node = new Node<>();
        node.setItem(item);
        Node<T> current = this.head;
        if (this.head != null && position <= this.size) {
            for (int i = 1; i < position; i++) {
                current = current.getNext();
            }
            node.setNext(current.getNext());
            current.setNext(node);
            this.size += 1;
        } else {
            System.out.println("Exceeded the linked list size. Current Size: " + size);
        }
    }

    public void deleteNthNode(T key) {
        Node<T> currentNode = this.head;
        Node<T> prevNode = null;
        if (currentNode != null && currentNode.getItem() == key) {
            head = currentNode.getNext();
            return;
        }
        while (currentNode != null && currentNode.getItem() != key) {
            prevNode = currentNode;
            currentNode = currentNode.getNext();
        }

        if (currentNode == null) {
            return;
        }

        prevNode.setNext(currentNode.getNext());

    }

    public T findNodeAt(int location) {
        Node<T> node = this.head;
        if (head != null && location <= size) {
            for (int i = 0; i < location; i++) {
                node = node.getNext();
            }

        }
        return node.getItem();
    }

}
