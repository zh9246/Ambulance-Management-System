/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AmbulanceServiceSystem;

/**
 *
 * @author Hassan Nawaz
 */
public class Node_EMTs {    
  	private EMTs item;
  	private Node_EMTs next;

    public void setItem(EMTs item) {
        this.item = item;
    }

    public void setNext(Node_EMTs next) {
        this.next = next;
    }

    public EMTs getItem() {
        return item;
    }

    public Node_EMTs getNext() {
        return next;
    }
}
