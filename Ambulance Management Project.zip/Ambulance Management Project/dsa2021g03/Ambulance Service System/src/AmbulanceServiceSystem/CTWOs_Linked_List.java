/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AmbulanceServiceSystem;

/**
 *
 * @author Hassan Nawaz
 */
public class CTWOs_Linked_List {
    private static CTWOs_Linked_List inst=null;
     private int size;
     private Node_CTWOs head;

	private CTWOs_Linked_List() {
		this.size = 0;
		this.head = null;
	}

         //getter
    public static CTWOs_Linked_List getInst() {
        if(inst!=null)
        {
        return inst;
        }
        else{
            inst=new CTWOs_Linked_List();
            return inst;
        }
    }

    public int getSize() {
        return size;
    }

    public Node_CTWOs getHead() {
        return head;
    }
	public void insertFirst(CTWOs item){
		Node_CTWOs node = new Node_CTWOs();
		node.setItem(item);
		node.setNext(this.head);
		this.head = node;
		this.size++;
	}
	public void insertNth(CTWOs item, int position) {
		Node_CTWOs node = new Node_CTWOs();
		node.setItem(item);
		Node_CTWOs current = this.head;
		if (this.head != null && position <= this.size) {
			for (int i = 1; i < position; i++) {
				current = current.getNext();
			}
			node.setNext(current.getNext());
			current.setNext(node);
			this.size += 1;
		}else{
			System.out.println("Exceeded the linked list size. Current Size: "+size);
		}
	}
	public void deleteNthNode(int position) {
		if (position <= this.size && this.head != null) {
			Node_CTWOs currentNode = this.head;
			Node_CTWOs prevNode = null;
			for (int i = 0; i < position; i++) {
				prevNode = currentNode;
				currentNode = currentNode.getNext();
			}
			prevNode.setNext(currentNode.getNext());
			this.size--;
		}else{
			System.out.println("No node exist at location: "+position);
		}
	}
	public void findNode(CTWOs item) {
		Node_CTWOs node = this.head;
		boolean found = false;
		for(int i=0;i<size; i++){
			if(node.getItem().equals(item)){
				System.out.println("Item "+item+" was found at location "+i+" in the linked list");
				found = true;
			}
			node = node.getNext();
		}
		
		if(!found)
			System.out.println("Item "+item+" was not found in the Linked list");
	}
	public void findNodeAt(int location) {
		Node_CTWOs node = this.head;
		if(head !=null && location<= size){
			for(int i=0;i<location;i++){
				node = node.getNext();
			}
			System.out.println("Node item at location "+location+" is "+node.getItem());
		}
	}
	public void printNodes() {
		if (this.size < 1)
                {
			System.out.println("There are no nodes in the linked list");
                }
		else {
			Node_CTWOs current = this.head;
			for (int i = 0; i < this.size; i++)
                        {
				System.out.println("Node " + current.getItem().Name + " is at location " + i);
				current = current.getNext();
			}
		}
	}
	public int getListSize(){
		return size;
	}
    
    
}
