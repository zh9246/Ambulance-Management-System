/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AmbulanceServiceSystem;

import java.util.NoSuchElementException;

/**
 *
 * @author Hassan Nawaz
 */
public class Queue_CTWOs {
       private Node_CTWOs first;
        private static Queue_CTWOs inst=null;
	private Queue_CTWOs()
	{
		first = null;
	}
        
        public static Queue_CTWOs getInst()
        {
            if(inst!=null)
            {
                return inst;
            }
            else
            {
                inst=new Queue_CTWOs();
                return inst;
            }
        }
	public void insertFirst(CTWOs x)
	{
		Node_CTWOs n = new Node_CTWOs();
		n.setItem(x);
		n.setNext(first);
		first = n;
	}

	public void enqueue(CTWOs x)
	{
		if (first == null)
		{
			insertFirst(x);
		}
		else
		{
			Node_CTWOs n = new Node_CTWOs();
			n.setItem(x);
			Node_CTWOs temp = first;
			while (temp.getItem() != null)
				temp = temp.getNext();
			n.setNext(temp.getNext());
			temp.setNext(n);
		}
	}

	public CTWOs dequeue()
	{
		if (first == null)
		{
			throw new NoSuchElementException();
		}
		else
		{
			CTWOs ret = first.getItem();
			first = first.getNext();
			return ret;
		}
	}

	public CTWOs peek()
	{
		if (first == null)
		{
			throw new NoSuchElementException();
		}
		else
		{
			return first.getItem();
		}
	}
}
