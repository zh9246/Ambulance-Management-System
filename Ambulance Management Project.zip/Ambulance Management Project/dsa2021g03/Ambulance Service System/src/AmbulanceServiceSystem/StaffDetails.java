/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AmbulanceServiceSystem;

/**
 *
 * @author Proud To Be Muslims
 */
import java.util.Date;

public class StaffDetails {

    private String name;
    private String CNIC;
    private Date DOB;
    private String Address;
    private String RefPhoneNumber;
    private String phoneNumber;
    private String states;
    private String ID;
    private static int idnum=1;

     public StaffDetails()
     {
         
     }
    public StaffDetails(String name, String CNIC, Date DOB, String address, String refPhoneNumber, String phoneNumber, String states, String id) {
        this.name = name;
        this.CNIC = CNIC;
        this.DOB = DOB;
        Address = address;
        RefPhoneNumber = refPhoneNumber;
        this.phoneNumber = phoneNumber;
        this.states = states;
        ID = id;
    }

    public String getID() {
        return ID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCNIC() {
        return CNIC;
    }

    public void setCNIC(String CNIC) {
        this.CNIC = CNIC;
    }

    public Date getDOB() {
        return DOB;
    }

    public void setDOB(Date DOB) {
        this.DOB = DOB;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getRefPhoneNumber() {
        return RefPhoneNumber;
    }

    public void setRefPhoneNumber(String refPhoneNumber) {
        RefPhoneNumber = refPhoneNumber;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getStates() {
        return states;
    }

    public void setStates(String states) {
        this.states = states;
    }
    
   
    /**
     * setter For EmployeeID
     *
     * @param num
     * @return boolean
     */
    public void setID() {
        
        String id = "Staff-" + idnum;
        this.ID = id;
        idnum++;
    }
     
     
}

