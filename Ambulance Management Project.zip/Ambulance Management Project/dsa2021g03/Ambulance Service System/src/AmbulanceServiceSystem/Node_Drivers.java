/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AmbulanceServiceSystem;

/**
 *
 * @author Hassan Nawaz
 */
public class Node_Drivers {
    private Drivers item;
  	private Node_Drivers next;

    public void setItem(Drivers item) {
        this.item = item;
    }

    public void setNext(Node_Drivers next) {
        this.next = next;
    }

    public Drivers getItem() {
        return item;
    }

    public Node_Drivers getNext() {
        return next;
    }
    
}
