/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AmbulanceServiceSystem;

/**
 *
 * @author Hassan Nawaz
 */
public class Equipment {
    private String Name;
    private String Amount;
    private String Used_for;

    public Equipment(String Name, String Amount, String Used_for) {
        this.Name = Name;
        this.Amount = Amount;
        this.Used_for = Used_for;
    }

    public String getName() {
        return Name;
    }

    public String getAmount() {
        return Amount;
    }

    public String getUsed_for() {
        return Used_for;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public void setAmount(String Amount) {
        this.Amount = Amount;
    }

    public void setUsed_for(String Used_for) {
        this.Used_for = Used_for;
    }
    
}
