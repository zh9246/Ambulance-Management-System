/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AmbulanceServiceSystem;

import java.util.NoSuchElementException;

/**
 *
 * @author Hassan Nawaz
 */
public class Queue_Drivers {
    private Node_Drivers first;
        private static Queue_Drivers inst=null;
	private Queue_Drivers()
	{
		first = null;
	}
        
        public static Queue_Drivers getInst()
        {
            if(inst!=null)
            {
                return inst;
            }
            else
            {
                inst=new Queue_Drivers();
                return inst;
            }
        }
	public void insertFirst(Drivers x)
	{
		Node_Drivers n = new Node_Drivers();
		n.setItem(x);
		n.setNext(first);
		first = n;
	}

	public void enqueue(Drivers x)
	{
		if (first == null)
		{
			insertFirst(x);
		}
		else
		{
			Node_Drivers n = new Node_Drivers();
			n.setItem(x);
			Node_Drivers temp = first;
			while (temp.getItem() != null)
				temp = temp.getNext();
			n.setNext(temp.getNext());
			temp.setNext(n);
		}
	}

	public Drivers dequeue()
	{
		if (first == null)
		{
			throw new NoSuchElementException();
		}
		else
		{
			Drivers ret = first.getItem();
			first = first.getNext();
			return ret;
		}
	}

	public Drivers peek()
	{
		if (first == null)
		{
			throw new NoSuchElementException();
		}
		else
		{
			return first.getItem();
		}
	}
}
