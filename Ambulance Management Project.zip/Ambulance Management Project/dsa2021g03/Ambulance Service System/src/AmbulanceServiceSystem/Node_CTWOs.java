/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AmbulanceServiceSystem;

/**
 *
 * @author Hassan Nawaz
 */
public class Node_CTWOs {
    private CTWOs item;
  	private Node_CTWOs next;

    public void setItem(CTWOs item) {
        this.item = item;
    }

    public void setNext(Node_CTWOs next) {
        this.next = next;
    }

    public CTWOs getItem() {
        return item;
    }

    public Node_CTWOs getNext() {
        return next;
    }
}
